package com.elevatelabs.bookstoreapi.service;

import com.elevatelabs.bookstoreapi.dto.AuthorRequest;
import com.elevatelabs.bookstoreapi.entity.Author;
import com.elevatelabs.bookstoreapi.exception.ResourceNotFoundException;
import com.elevatelabs.bookstoreapi.repository.AuthorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorService(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    public Author createAuthor(AuthorRequest request) {
        Author author = new Author(request.getName(), request.getEmail(), request.getBio());
        return authorRepository.save(author);
    }

    public List<Author> getAllAuthors() {
        return authorRepository.findAll();
    }

    public Author getAuthorById(Long id) {
        return authorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Author not found with id: " + id));
    }

    public Author updateAuthor(Long id, AuthorRequest request) {
        Author author = getAuthorById(id);
        author.setName(request.getName());
        author.setEmail(request.getEmail());
        author.setBio(request.getBio());
        return authorRepository.save(author);
    }

    public void deleteAuthor(Long id) {
        Author author = getAuthorById(id);
        authorRepository.delete(author);
    }
}
