package com.elevatelabs.bookstoreapi.controller;

import com.elevatelabs.bookstoreapi.dto.BookRequest;
import com.elevatelabs.bookstoreapi.entity.Book;
import com.elevatelabs.bookstoreapi.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
@Tag(name = "Books", description = "Endpoints for managing books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @PostMapping
    @Operation(summary = "Create a new book")
    public ResponseEntity<Book> createBook(@Valid @RequestBody BookRequest request) {
        Book created = bookService.createBook(request);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get books with optional filtering, pagination, and sorting",
            description = "Supports filtering by title, genre, author name, and price range. " +
                    "Use page, size, and sort query params for pagination and sorting, e.g. ?sort=price,desc")
    public ResponseEntity<Page<Book>> getBooks(
            @Parameter(description = "Partial, case-insensitive match on title")
            @RequestParam(required = false) String title,
            @Parameter(description = "Exact, case-insensitive match on genre")
            @RequestParam(required = false) String genre,
            @Parameter(description = "Partial, case-insensitive match on the author's name")
            @RequestParam(required = false) String authorName,
            @Parameter(description = "Minimum price, inclusive")
            @RequestParam(required = false) Double minPrice,
            @Parameter(description = "Maximum price, inclusive")
            @RequestParam(required = false) Double maxPrice,
            @PageableDefault(size = 10, sort = "title", direction = Sort.Direction.ASC) Pageable pageable) {

        Page<Book> books = bookService.getBooks(title, genre, authorName, minPrice, maxPrice, pageable);
        return ResponseEntity.ok(books);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a single book by id")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        return ResponseEntity.ok(bookService.getBookById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing book")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @Valid @RequestBody BookRequest request) {
        return ResponseEntity.ok(bookService.updateBook(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a book")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }
}
