package com.elevatelabs.bookstoreapi.service;

import com.elevatelabs.bookstoreapi.dto.BookRequest;
import com.elevatelabs.bookstoreapi.entity.Author;
import com.elevatelabs.bookstoreapi.entity.Book;
import com.elevatelabs.bookstoreapi.exception.ResourceNotFoundException;
import com.elevatelabs.bookstoreapi.repository.AuthorRepository;
import com.elevatelabs.bookstoreapi.repository.BookRepository;
import com.elevatelabs.bookstoreapi.specification.BookSpecification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookService(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    public Book createBook(BookRequest request) {
        Author author = authorRepository.findById(request.getAuthorId())
                .orElseThrow(() -> new ResourceNotFoundException("Author not found with id: " + request.getAuthorId()));

        Book book = new Book(
                request.getTitle(),
                request.getIsbn(),
                request.getGenre(),
                request.getPrice(),
                request.getPublishedDate(),
                author
        );
        return bookRepository.save(book);
    }

    public Page<Book> getBooks(String title, String genre, String authorName,
                                Double minPrice, Double maxPrice, Pageable pageable) {
        Specification<Book> spec = Specification
                .where(BookSpecification.hasTitle(title))
                .and(BookSpecification.hasGenre(genre))
                .and(BookSpecification.hasAuthorName(authorName))
                .and(BookSpecification.priceGreaterThanOrEqual(minPrice))
                .and(BookSpecification.priceLessThanOrEqual(maxPrice));

        return bookRepository.findAll(spec, pageable);
    }

    public Book getBookById(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
    }

    public Book updateBook(Long id, BookRequest request) {
        Book book = getBookById(id);

        Author author = authorRepository.findById(request.getAuthorId())
                .orElseThrow(() -> new ResourceNotFoundException("Author not found with id: " + request.getAuthorId()));

        book.setTitle(request.getTitle());
        book.setIsbn(request.getIsbn());
        book.setGenre(request.getGenre());
        book.setPrice(request.getPrice());
        book.setPublishedDate(request.getPublishedDate());
        book.setAuthor(author);

        return bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        Book book = getBookById(id);
        bookRepository.delete(book);
    }
}
