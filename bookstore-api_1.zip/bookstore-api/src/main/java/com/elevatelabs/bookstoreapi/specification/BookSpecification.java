package com.elevatelabs.bookstoreapi.specification;

import com.elevatelabs.bookstoreapi.entity.Book;
import org.springframework.data.jpa.domain.Specification;

public class BookSpecification {

    private BookSpecification() {
    }

    public static Specification<Book> hasTitle(String title) {
        return (root, query, cb) ->
                title == null || title.isBlank()
                        ? null
                        : cb.like(cb.lower(root.get("title")), "%" + title.toLowerCase() + "%");
    }

    public static Specification<Book> hasGenre(String genre) {
        return (root, query, cb) ->
                genre == null || genre.isBlank()
                        ? null
                        : cb.equal(cb.lower(root.get("genre")), genre.toLowerCase());
    }

    public static Specification<Book> hasAuthorName(String authorName) {
        return (root, query, cb) ->
                authorName == null || authorName.isBlank()
                        ? null
                        : cb.like(cb.lower(root.join("author").get("name")), "%" + authorName.toLowerCase() + "%");
    }

    public static Specification<Book> priceGreaterThanOrEqual(Double minPrice) {
        return (root, query, cb) ->
                minPrice == null ? null : cb.greaterThanOrEqualTo(root.get("price"), minPrice);
    }

    public static Specification<Book> priceLessThanOrEqual(Double maxPrice) {
        return (root, query, cb) ->
                maxPrice == null ? null : cb.lessThanOrEqualTo(root.get("price"), maxPrice);
    }
}
